﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background : MonoBehaviour
{
    public GameObject[] levels;
    public Transform girl;
    private Camera main;
    private Vector2 bounds;
    public float choke;
    // Start is called before the first frame update
    void Start()
    {
        main = gameObject.GetComponent<Camera>();
        bounds = main.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, main.transform.position.z));
        foreach(GameObject obj in levels)
        {
            loadChildObjects(obj);
        }

    }

    void loadChildObjects(GameObject obj)
    {
        float objWidth = obj.GetComponent<SpriteRenderer>().bounds.size.x - choke;
        int needed = (int)Mathf.Ceil(bounds.x * 2 / objWidth);
        GameObject copy = Instantiate(obj) as GameObject;
        for(int i = 0; i <= needed; i++)
        {
            GameObject c = Instantiate(copy) as GameObject;
            c.transform.SetParent(obj.transform);
            c.transform.position = new Vector3(objWidth * i, obj.transform.position.y, obj.transform.position.z);
            c.name = obj.name + i;
        }
        Destroy(copy);
        Destroy(obj.GetComponent<SpriteRenderer>());
    }

    void repositionChild(GameObject obj)
    {
        Transform[] children = obj.GetComponentsInChildren<Transform>();
        if(children.Length > 1)
        {
            GameObject first = children[1].gameObject;
            GameObject last = children[children.Length - 1].gameObject;
            float halfway = last.GetComponent<SpriteRenderer>().bounds.extents.x - choke;
            if(transform.position.x + bounds.x > last.transform.position.x + halfway)
            {
                first.transform.SetAsLastSibling();
                first.transform.position = new Vector3(last.transform.position.x + halfway * 2, last.transform.position.y, last.transform.position.z);
            }
            else if(transform.position.x - bounds.x < first.transform.position.x - halfway)
            {
                last.transform.SetAsFirstSibling();
                last.transform.position = new Vector3(first.transform.position.x - halfway * 2, first.transform.position.y, first.transform.position.z);
            }
        }
    }

    void LateUpdate()
    {
        foreach(GameObject obj in levels)
        {
            repositionChild(obj);
        }
    }

    void FixedUpdate()
    {
        this.transform.position = new Vector3(girl.transform.position.x, 3.42f, -10f);
    }
}
