using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Scoring : MonoBehaviour
{
    public static Scoring balls;
    public TextMeshProUGUI text;
    public int score;
    // Start is called before the first frame update
    void Start()
    {
        if (balls == null)
        {
            balls = this;
        }
    }

    public void Increment(int collected)
    {
        score += collected;
        text.text = "x" + score.ToString();
    }
}
