﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    private SpriteRenderer sr;
    private Animator anm;
    public float speed = 5f;
    public float jump = 3f;
    public GameObject pullback;
    public GameObject[] toys;
    Rigidbody2D rb;
    // Start is called before the first frame update
    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        anm = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        toys = GameObject.FindGameObjectsWithTag("Toy");
        if (this.gameObject.tag == "Girl")
        {
            if (Input.GetKey(KeyCode.A))
            {
                rb.velocity = new Vector2(-speed, rb.velocity.y);
                anm.SetBool("Run", true);
                sr.flipX = true;
            }
            else if (Input.GetKey(KeyCode.D))
            {
                rb.velocity = new Vector2(speed, rb.velocity.y);
                anm.SetBool("Run", true);
                sr.flipX = false;
            }
            else
            {
                rb.velocity = new Vector2(0f, rb.velocity.y);
                anm.SetBool("Run", false);
                anm.SetBool("Launch", false);
            }
            if (Input.GetKey(KeyCode.W))
            {
                if (rb.velocity.y == 0f)
                    rb.velocity = new Vector2(rb.velocity.x, jump);
            }
        }
        else if(this.gameObject.tag == "Boy") 
        {
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                rb.velocity = new Vector2(-speed, rb.velocity.y);
                anm.SetBool("Run", true);
                sr.flipX = true;
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                rb.velocity = new Vector2(speed, rb.velocity.y);
                anm.SetBool("Run", true);
                sr.flipX = false;
            }
            else
            {
                rb.velocity = new Vector2(0f, rb.velocity.y);
                anm.SetBool("Run", false);
            }
            if (Input.GetKey(KeyCode.UpArrow))
            {
                if (rb.velocity.y == 0f)
                    rb.velocity = new Vector2(rb.velocity.x, jump);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (this.gameObject.tag == "Boy")
        {
            if(col.gameObject.tag == "Girl")
            {
                rb.velocity = new Vector2(0f, jump*5);
            }
            if (col.gameObject.tag == "Return")
            {
                this.transform.position = new Vector3(this.transform.position.x - 290f, this.transform.position.y, 0f);
                pullback = GameObject.FindWithTag("Girl");
                pullback.transform.position = new Vector3(pullback.transform.position.x - 290f, pullback.transform.position.y, 0f);
            }
        }
        else if(this.gameObject.tag == "Girl")
        {
            if(col.gameObject.tag == "Boy")
            {
                anm.SetBool("Launch",true);
            }
            if (col.gameObject.tag == "Return")
            {
                this.transform.position = new Vector3(this.transform.position.x - 290f, this.transform.position.y, 0);
                pullback = GameObject.FindWithTag("Boy");
                pullback.transform.position = new Vector3(pullback.transform.position.x - 290f, pullback.transform.position.y, 0f);
            }
        }
        if (col.gameObject.CompareTag("Toy"))
        {
            Destroy(col.gameObject);
        }
        if(col.gameObject.name == "Bad" || col.gameObject.name == "Witch")
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
        if(col.gameObject.name == "Finish")
        {
            if(toys.Length != 0)
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
            else
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 3);
        }
    }

    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.gameObject.name == "Flashlight")
        {
            Destroy(col.gameObject);
        }
    }
}
